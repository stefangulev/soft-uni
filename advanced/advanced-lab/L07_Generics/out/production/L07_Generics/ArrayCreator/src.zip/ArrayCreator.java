import java.lang.reflect.Array;

public class ArrayCreator<T> {

    @SuppressWarnings("unchecked")
    public static <T> T[] create(int length, T element) {

        Object arr = Array.newInstance(element.getClass(), length);

        return (T[]) arr;

    }

    @SuppressWarnings("unchecked")
    public static <T> T[] create (Class<T> clazz,  int length, T element) {
        Object arr = Array.newInstance(clazz, length);

        return (T[])arr;
    }
}
