package guild;

import java.util.*;
import java.util.stream.Collectors;

public class Guild {
    LinkedHashMap<String, Player> roster;
    String name;
    int capacity;


    public Guild(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.roster = new LinkedHashMap<>();
    }

    public void addPlayer(Player player) {
        if (this.roster.size() < capacity) {
            roster.put(player.getName(), player);
        }
    }

    public boolean removePlayer(String name) {
         return roster.remove(name, roster.get(name));
    }

    public void promotePlayer (String name) {
        roster.get(name).setRank("Member");
    }
    public void demotePlayer (String name) {
        roster.get(name).setRank("Trial");
    }

    public Player[] kickPlayersByClass (String clazz) {
       Player[] removed = roster.values().stream().filter(e -> e.getClazz().equals(clazz)).toArray(Player[]::new);
        for (Player player : removed) {
            roster.remove(player.getName());
        }
       return removed;
    }

    public int count() {
        return roster.size();
    }

    public String report() {
        System.out.println();
        String result = String.format("Players in the guild: %s:%n", this.name);
        for (Player value : roster.values()) {
            result += String.format("%s%n", value);
        }
        return result;
    }

}

