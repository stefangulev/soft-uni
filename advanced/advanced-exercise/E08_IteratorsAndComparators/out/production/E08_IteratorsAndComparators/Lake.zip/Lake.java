import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Lake implements Iterable<Integer> {
    List<Integer> lakeNumbers;

    public Lake(int... numbers) {
        lakeNumbers = new ArrayList<>();
        for (int i = 0; i < numbers.length ; i++) {
            this.lakeNumbers.add(numbers[i]);
        }

    }

    public class LakeIterator implements Iterator<Integer> {

        private int index;
        @Override
        public boolean hasNext() {
            return index < lakeNumbers.size();
        }

        @Override
        public Integer next() {
            int current = lakeNumbers.get(index);
            index++;
            return current;
        }
    }

    public static class Frog {
        private List<Integer> jumpedOverNumbersOdd = new ArrayList<>();
        private List<Integer> jumpedOverNumbersEven = new ArrayList<>();

        public void jump(int element) {
            if (element % 2 == 0) {
                jumpedOverNumbersEven.add(element);
            } else {
                jumpedOverNumbersOdd.add(element);
            }
        }

        public void printOdd() {
            for (Integer integer : jumpedOverNumbersOdd) {
                System.out.print(integer + ", ");
            }
        }

        public void printEven() {
            for (int i = 0; i < jumpedOverNumbersEven.size(); i++) {
                if (i == jumpedOverNumbersEven.size() - 1) {
                    System.out.print(jumpedOverNumbersEven.get(i));
                } else {
                    System.out.print(jumpedOverNumbersEven.get(i) + ", ");
                }
            }
        }
    }


    @Override
    public Iterator<Integer> iterator() {
            return new LakeIterator();
    }
}
