import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int[] lakeNumbers = Arrays.stream(scan.nextLine().split(", ")).mapToInt(Integer::parseInt).toArray();

        Lake lake = new Lake(lakeNumbers);

        String secondCommand = scan.nextLine();

        Lake.Frog frog = new Lake.Frog();
        for (Integer integer : lake) {
            frog.jump(integer);
        }

        frog.printOdd();
        //if it has only odd numbers last element will be printed with coma
        frog.printEven();
    }
}
