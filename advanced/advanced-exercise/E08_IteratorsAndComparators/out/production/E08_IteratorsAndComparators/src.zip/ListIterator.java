import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListIterator {
    private List<String> list;

    int index = 0;

    public ListIterator(List<String> list) {
        this.list = list;
    }

    public boolean move() {
        if (hasNext()) {
            index++;
            return true;
        } else {
            return false;
        }
    }

    public boolean hasNext() {
        return this.index < list.size() -1;
    }
    public void print() {
      try {
          if (this.list.size() != 0) {
              System.out.println(this.list.get(index));
          } else {
              throw new NullPointerException("Invalid Operation!");
          }
      } catch (NullPointerException ex) {
          System.out.println(ex.getMessage());
      }
    }


}
