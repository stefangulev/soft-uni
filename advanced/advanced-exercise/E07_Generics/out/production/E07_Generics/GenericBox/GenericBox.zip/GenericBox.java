import java.util.List;

public class GenericBox<T> {

   private T element;

   public GenericBox(T element) {
       this.element = element;
   }

    public void swapIndexes (List<T> list, int firstIndex, int secondIndex) {
        T firstItem = list.remove(firstIndex);
        T secondItem = list.remove(secondIndex);

        list.add(firstIndex, secondItem);
        list.add(secondIndex, firstItem);

        for (T t : list) {
            for (T t1 : list) {
                System.out.println(t1);
            }
        }
    }


    @Override
    public String toString() {
        return element.getClass().getName() +": " + element;
    }
}
