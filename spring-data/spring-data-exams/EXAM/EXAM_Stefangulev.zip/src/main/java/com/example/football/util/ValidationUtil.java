package com.example.football.util;


public interface ValidationUtil {

    <T> boolean isValid(T entity);
}
