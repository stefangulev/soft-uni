package wildfarm;

public abstract class Felime extends Mammal {


    protected Felime(String animalType, String animalName, Double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }
}
