package wildfarm;

public class Vegetable extends Food {
    protected Vegetable(Integer quantity) {
        super(quantity);
    }
}
