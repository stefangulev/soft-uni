package vehicle;

import java.text.DecimalFormat;

public class Car extends Vehicle {

    public Car(double fuelQuantity, double fuelConsumptionPerKm) {
        super(fuelQuantity, fuelConsumptionPerKm + 0.9);
    }


    @Override
    protected String drive(Double distance) {
        if (!checkFuelEnoughForDrive(distance)) {
            return "Car needs refueling";
        } else {
            super.setFuelQuantity(super.getFuelQuantity() - (super.getFuelConsumptionInLitersPerKm() * distance));
            return String.format("Car travelled %s km", getFormatter().format(distance));
        }
    }

    @Override
    protected void refuel(Double liters) {
        super.setFuelQuantity(super.getFuelQuantity() + liters);
    }
}
