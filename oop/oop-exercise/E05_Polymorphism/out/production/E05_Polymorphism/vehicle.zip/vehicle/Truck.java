package vehicle;

public class Truck extends Vehicle {
    protected Truck(double fuelQuantity, double fuelConsumptionInLitersPerKm) {
        super(fuelQuantity, fuelConsumptionInLitersPerKm + 1.6);
    }

    @Override
    protected String drive(Double distance) {
        if (!checkFuelEnoughForDrive(distance)) {
            return "Truck needs refueling";
        } else {
            super.setFuelQuantity(super.getFuelQuantity() - (super.getFuelConsumptionInLitersPerKm() * distance));
            return String.format("Truck travelled %s km", getFormatter().format(distance));
        }
    }

    @Override
    protected void refuel(Double liters) {
        super.setFuelQuantity(super.getFuelQuantity() + (liters * 0.95));
    }
}
