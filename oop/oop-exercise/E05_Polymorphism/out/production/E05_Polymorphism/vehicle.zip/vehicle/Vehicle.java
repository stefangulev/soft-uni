package vehicle;

import java.text.DecimalFormat;

public abstract class Vehicle {
    private double fuelQuantity;
    private double fuelConsumptionInLitersPerKm;
    private DecimalFormat formatter;

    protected Vehicle(double fuelQuantity, double fuelConsumptionInLitersPerKm) {
        setFuelQuantity(fuelQuantity);
        setFuelConsumptionInLitersPerKm(fuelConsumptionInLitersPerKm);
        this.formatter = new DecimalFormat("##.##");
    }

    protected void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    protected void setFuelConsumptionInLitersPerKm(double fuelConsumptionInLitersPerKm) {
        this.fuelConsumptionInLitersPerKm = fuelConsumptionInLitersPerKm;
    }

    public DecimalFormat getFormatter() {
        return formatter;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    protected double getFuelConsumptionInLitersPerKm() {
        return fuelConsumptionInLitersPerKm;
    }

    protected abstract String drive(Double distance);
    protected abstract void refuel(Double liters);
    protected boolean checkFuelEnoughForDrive(double distance) {
        return distance * getFuelConsumptionInLitersPerKm() <= getFuelQuantity();
    }
}
