package AnimalFarm;

public class Main {
    public static void main(String[] args) {
        Chicken chicken = new Chicken("", 17);

        System.out.println(chicken);
    }
}
