public enum CardSuit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;


    public static CardSuit[] getCardValues() {
        return CardSuit.values();
    }


}
