package interfacePerson;

public interface Buyer {
    int getFood();
    void buyFood();
}
