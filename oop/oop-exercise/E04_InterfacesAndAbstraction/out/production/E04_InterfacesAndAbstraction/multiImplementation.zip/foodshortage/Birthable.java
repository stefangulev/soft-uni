package interfacePerson;

public interface Birthable {
    String getBirthDate();
}
