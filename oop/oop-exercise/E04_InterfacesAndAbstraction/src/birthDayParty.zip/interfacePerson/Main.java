package interfacePerson;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {

        public static void main(String[] args) {
            Scanner scan = new Scanner(System.in);

            List<Birthable> birthables = new ArrayList<>();

            String input = scan.nextLine();

            while (!input.equals("End")) {
                String[] tokens = input.split("\\s+");

                if (tokens[0].equals("Citizen")) {
                    birthables.add(new Citizen(tokens[1], Integer.parseInt(tokens[2]), tokens[3], tokens[4]));
                } else if (tokens[0].equals("Pet")) {
                    birthables.add(new Pet(tokens[1], tokens[2]));
                }

                input = scan.nextLine();
            }

            String birthYearToFind = scan.nextLine();

            for (Birthable birthable : birthables) {
                if (birthable.getBirthDate().endsWith(birthYearToFind)) {
                    System.out.println(birthable.getBirthDate());
                }
            }


        }


}
