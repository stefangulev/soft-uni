package hero;

public class Main {

    public static void main(String[] args) {

        DarkKnight knight = new DarkKnight("gencho", 12);

        System.out.println(knight.getUsername());

        System.out.println(knight);
    }
}
