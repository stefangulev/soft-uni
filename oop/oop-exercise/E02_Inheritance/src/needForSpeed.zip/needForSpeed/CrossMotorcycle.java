package needForSpeed;

public class CrossMotorcycle extends Motorcycle {

    public CrossMotorcycle(double fuel, int horsepower) {
        super(fuel, horsepower);

    }
}
