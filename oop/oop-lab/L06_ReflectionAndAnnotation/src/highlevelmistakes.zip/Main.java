import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.file.attribute.AclFileAttributeView;
import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
//        Class<?> clazz = Reflection.class;
//        System.out.println(clazz);
//        System.out.println(clazz.getSuperclass());
//        Arrays.stream(clazz.getInterfaces()).forEach(System.out::println);
//        Reflection o = (Reflection)clazz.getDeclaredConstructor().newInstance();
//        System.out.println(o);


        Class<?> clazz = Reflection.class;

        Set<Field> fields = Arrays.stream(clazz.getDeclaredFields()).sorted(Comparator.comparing(Field::getName)).collect(Collectors.toCollection(LinkedHashSet::new));

        Set<Method> getters = Arrays.stream(clazz.getDeclaredMethods()).
                filter(method -> method.getName().startsWith("get") && method.getReturnType() != Void.class)
                .sorted(Comparator.comparing(Method::getName)).collect(Collectors.toCollection(LinkedHashSet::new));


        Set<Method> setters = Arrays.stream(clazz.getDeclaredMethods()).
                filter(method -> method.getName().startsWith("set") && method.getParameterCount() == 1)
                .sorted(Comparator.comparing(Method::getName))
                .collect(Collectors.toCollection(LinkedHashSet::new));

        for (Field declaredField : fields) {
            if (!Modifier.isPrivate(declaredField.getModifiers())) {
                System.out.println(declaredField.getName() + " must be private!");
            }
        }

        for (Method getter : getters) {
            if (!Modifier.isPublic(getter.getModifiers())) {
                System.out.println(getter.getName() + " have to be public!");
            }
        }

        for (Method setter : setters) {
            if (!Modifier.isPrivate(setter.getModifiers())) {
                System.out.println(setter.getName() + " have to be private!");
            }
        }

    }
}
