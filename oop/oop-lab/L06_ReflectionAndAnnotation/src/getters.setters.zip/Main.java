import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.attribute.AclFileAttributeView;
import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
//        Class<?> clazz = Reflection.class;
//        System.out.println(clazz);
//        System.out.println(clazz.getSuperclass());
//        Arrays.stream(clazz.getInterfaces()).forEach(System.out::println);
//        Reflection o = (Reflection)clazz.getDeclaredConstructor().newInstance();
//        System.out.println(o);


        Class<?> clazz = Reflection.class;

        Set<Method> getters = Arrays.stream(clazz.getDeclaredMethods()).
                filter(method -> method.getName().startsWith("get") && method.getReturnType() != Void.class)
                .sorted(Comparator.comparing(Method::getName)).collect(Collectors.toCollection(LinkedHashSet::new));


        Set<Method> setters = Arrays.stream(clazz.getDeclaredMethods()).
                filter(method -> method.getName().startsWith("set") && method.getParameterCount() == 1)
                .sorted(Comparator.comparing(Method::getName))
                .collect(Collectors.toCollection(LinkedHashSet::new));

        for (Method getter : getters) {
            System.out.println(String.format("%s will return class %s", getter.getName(), getter.getReturnType().getName().replace("class", "")));
        }

        for (Method setter : setters) {
            System.out.println(String.format("%s and will set field of class %s", setter.getName(), setter.getParameterTypes()[0].getName().replace("class", "")));

        }



    }
}
