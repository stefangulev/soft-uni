package single;

public class Animal {

    public void eat() {
        System.out.println("eating...");
    }
}
