package CarShop;

public interface Rentable {

    public Integer getMinRentDay();

    public Double getPricePerDay();
}
