package CarShop;

public interface Sellable {

    public Double getPrice();
}
