package border;

public interface Identifiable {

    String getId();
}
