package robotService.models.procedures.interfaces;

import robotService.models.robots.interfaces.Robot;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseProcedure implements Procedure {
    protected List<Robot> robots;

    protected BaseProcedure() {
        this.robots = new ArrayList<>();
    }


    @Override
    public String history() {
        return null;
    }

    @Override
    public void doService(Robot robot, int procedureTime) {

    }

}
