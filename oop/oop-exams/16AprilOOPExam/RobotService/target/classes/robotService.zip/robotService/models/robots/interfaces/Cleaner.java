package robotService.models.robots.interfaces;

public class Cleaner extends BaseRobot {

    public Cleaner(String name, int energy, int happiness, int produceTime) {
        super(name, energy, happiness, produceTime);
    }

    @Override
    public String toString() {
        //there is a space in the beggining of the sentence.
        return super.toString();
    }
}
