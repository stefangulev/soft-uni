package robotService.models.robots.interfaces;

public abstract class BaseRobot implements Robot {

    private String name;
    private int happiness;
    private int energy;
    private int procedureTime;
    private String owner; //"Service" by default;
    private boolean isBought; //"false" by default;
    private boolean isRepaired; //"false" by default;

    protected BaseRobot(String name, int energy, int happiness, int produceTime) {
        this.name = name;
        setEnergy(energy);
        setHappiness(happiness);
        setProcedureTime(produceTime);
        this.owner = "Service";
        this.isBought = false;
        this.isRepaired = false;
    }


    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getHappiness() {
        return 0;
    }

    @Override
    public void setHappiness(int happiness) {

    }

    @Override
    public int getEnergy() {
        return 0;
    }

    @Override
    public void setEnergy(int energy) {

    }

    @Override
    public int getProcedureTime() {
        return 0;
    }

    @Override
    public void setProcedureTime(int procedureTime) {

    }

    @Override
    public void setOwner(String owner) {

    }

    @Override
    public void setBought(boolean bought) {

    }

    @Override
    public boolean isRepaired() {
        return false;
    }

    @Override
    public void setRepaired(boolean repaired) {

    }

}
