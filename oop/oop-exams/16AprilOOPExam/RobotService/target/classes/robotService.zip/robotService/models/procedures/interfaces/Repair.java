package robotService.models.procedures.interfaces;

import robotService.models.robots.interfaces.Robot;

public class Repair extends BaseProcedure {


    @Override
    public void doService(Robot robot, int procedureTime) {
        super.doService(robot, procedureTime);
    }
}
