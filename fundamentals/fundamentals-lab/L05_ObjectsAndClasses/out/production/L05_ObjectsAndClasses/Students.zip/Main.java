import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String line = scan.nextLine();
        List<Students> list = new ArrayList<>();

        while (!line.equals("end")) {
            String[] input = line.split(" ");

            String firstName = input[0];
            String lastName = input[1];
            int age = Integer.parseInt(input[2]);
            String hometown = input[3];

            Students student = new Students(firstName, lastName, age, hometown);

            list.add(student);

            line = scan.nextLine();

        }

        String requiredTown = scan.nextLine();

        for (Students students : list) {
            if (students.getHometown().equals(requiredTown)) {
                System.out.printf("%s %s is %d years old%n", students.getFirstName(), students.getLastName(), students.getAge());
            }
        }


    }
}
